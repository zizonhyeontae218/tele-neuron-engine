"""Run the 003ba held-out and diagnostic experiments after the fixed training budget."""
import copy
import json
from pathlib import Path

from diagnose import feedback_probe
from dynamath.v003a.ast import BASE
from research import measure, memory_probes, persist_model, synthetic, write_json
from train_control import ROOT, Model, evaluate, load, streams, train_language


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def rankings(directory, names, step):
    rows = []
    for name in names:
        item = read(directory / name / f"validation-{step:05}.json")
        if item["candidate"]["candidate"] != name or item["updates"] != step:
            raise ValueError(f"Invalid validation record for {name} at {step}")
        rows.append(dict(name=name, **item["metrics"]))
    ce = sorted(rows, key=lambda row: (row["response_CE"], row["fifo_eos_failure"], row["name"]))
    fifo = sorted(rows, key=lambda row: (row["fifo_question_emissions"], row["fifo_omission"],
                                        row["fifo_eos_failure"], row["fifo_uncomposed_jamo"],
                                        row["response_CE"], row["name"]))
    return ce, fifo


def fixed_controls(directory, output, splits, tokenizer, cfg, references):
    early_path = directory.parent / "003aa/research/early-control/control-step-003000.pt"
    early, first = Model.load(early_path)
    final_path = output / "fixed-control-step-10000.pt"
    if final_path.exists():
        final, payload = Model.load(final_path)
        restart = payload["restart"]
    else:
        final, payload = Model.load(early_path)
        restart = payload["restart"]
    assert first["restart"]["completed_steps"] == 3000
    x, y = streams(splits["train"][:512], tokenizer, cfg["batch"])
    step = restart["completed_steps"]
    while step < 10000:
        stats, restart = train_language(final, x, y,
            dict(cfg, steps=min(step + 250, 10000), seconds_cap_per_run=300), restart)
        assert stats["steps"] > step
        step = stats["steps"]
        persist_model(final, final_path, restart=restart, training=stats)
    controls = {}
    for step, model, path in ((3000, early, early_path), (10000, final, final_path)):
        observed = evaluate(model, splits["validation"], tokenizer)
        reference = references[str(step)]
        if abs(observed["response_CE"] - reference["response_CE"]) > 1e-6:
            raise ValueError(f"Fixed control at {step} does not replay the 003aa validation result")
        controls[step] = path
    return controls


def assess(model, splits, tokenizer, val_prompts, test_prompts, candidate):
    model.eval()
    result = {
        "validation": measure(model, splits["validation"], val_prompts, tokenizer),
        "test": measure(model, splits["test"], test_prompts, tokenizer),
        "multi_turn_memory": memory_probes(model, tokenizer),
        "validation_fifo_without_feedback": feedback_probe(model, val_prompts, tokenizer, feedback=False),
    }
    if candidate:
        restored = copy.deepcopy(model)
        restored.asts[0] = copy.deepcopy(BASE)
        result["restore_parent_formula"] = measure(restored, splits["validation"], val_prompts, tokenizer)
    return result


def run(directory):
    status = read(directory / "status.json")
    completed = read(directory / "results.json")
    protocol = read(directory / "protocol.json")
    names = protocol["candidate_order"]
    if (not status.get("complete") or status["total_steps"] != 500000 or
            status["completed_formulas"] != 50 or completed["completed"] != 50 or len(names) != 50):
        raise RuntimeError("Post-training research requires all 50 candidates and 500,000 updates")
    output = directory / "research"
    output.mkdir(exist_ok=True)
    if (output / "complete.json").is_file():
        print("003ba post-training research is already complete.", flush=True)
        return
    write_json(output / "status.json", {"phase": "validation_selection"})
    comparison = {}
    selections = {}
    for step in (3000, 10000):
        ce, fifo = rankings(directory, names, step)
        comparison[str(step)] = {"by_validation_ce": ce, "by_fifo": [row["name"] for row in fifo]}
        selections[str(step)] = {"validation_ce": ce[0]["name"], "fifo": fifo[0]["name"]}
    selection_path = output / "selection.json"
    if selection_path.exists() and read(selection_path) != selections:
        raise RuntimeError("The saved validation selection differs from the current ranking")
    write_json(selection_path, selections)
    write_json(output / "comparison.json", comparison)

    print("003ba selections frozen before post-training test:", selections, flush=True)
    splits, tokenizer = load(ROOT / "data/dynamath/001a")
    aa_plan = read(directory.parent / "003aa/research/protocol.json")
    assert [row["id"] for row in splits["train"][:512]] == protocol["train_ids"]
    assert [row["id"] for row in splits["validation"]] == protocol["validation_ids"]
    assert [row["id"] for row in splits["test"]] == aa_plan["test_ids"]
    val_lookup = {r["id"]: r for r in splits["validation"]}
    test_lookup = {r["id"]: r for r in splits["test"]}
    val_prompts = [val_lookup[i] for i in protocol["validation_fifo_ids"]]
    test_prompts = [test_lookup[i] for i in aa_plan["test_prompt_ids"]]
    cfg = read(ROOT / "configs/dynamath/experiment-003a.json")
    import torch
    torch.set_num_threads(cfg["threads"])
    write_json(output / "status.json", {"phase": "fixed_control_replay"})
    controls = fixed_controls(directory, output, splits, tokenizer, cfg, read(directory / "control-validation.json"))
    tests = {}
    for step, checkpoint in controls.items():
        entries = {"control": checkpoint}
        for name in selections[str(step)].values():
            entries[name] = directory / name / ("latest.pt" if step == 10000 else "step-03000.pt")
        for name, path in entries.items():
            key = f"{name}-{step:05}"
            record = output / f"assessment-{key}.json"
            if not record.exists():
                write_json(output / "status.json", {"phase": "assessment", "model": key})
                print("003ba assessing", key, flush=True)
                model, payload = Model.load(path)
                assert payload["restart"]["completed_steps"] == step
                data = assess(model, splits, tokenizer, val_prompts, test_prompts, name != "control")
                write_json(record, data)
            else:
                data = read(record)
            tests[key] = {
                "validation": data["validation"]["metrics"],
                "test": data["test"]["metrics"],
                "memory_hits_by_condition": {
                    f"{'cleared' if clear else 'preserved'}_{reset}": sum(
                        r["hit"] for r in data["multi_turn_memory"]
                        if r["clear_pending_feedback"] == clear and r["reset"] == reset)
                    for clear in (False, True) for reset in ("none", "S_only", "m_only", "both")
                },
                "validation_eos_without_feedback": sum(r["eos"] for r in data["validation_fifo_without_feedback"]),
                "restore_parent_validation_CE": data.get("restore_parent_formula", {}).get("metrics", {}).get("response_CE"),
            }
    write_json(output / "status.json", {"phase": "synthetic"})
    shortlist = read(directory.parent / "003aa/formula-shortlist.json")["candidates"]
    write_json(output / "synthetic.json", synthetic({"control": BASE, **{r["candidate"]: r["ast"] for r in shortlist}}))
    write_json(output / "complete.json",
               {"complete": True, "candidate_updates": status["total_steps"], "selections": selections,
                "test_prompt_ids": aa_plan["test_prompt_ids"], "assessments": tests})
    write_json(output / "status.json", {"phase": "complete"})
    print("003ba post-training research complete.", flush=True)

