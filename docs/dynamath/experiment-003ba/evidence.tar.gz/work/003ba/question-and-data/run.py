"""Compare data sampling and F1 structure with a fixed 3,000-update budget."""
from collections import Counter, defaultdict
from copy import deepcopy
import json
from pathlib import Path
import random
import statistics
import sys

import torch

HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE.parents[1] / "003aa"), str(HERE.parents[2] / "src")]
from train_control import ROOT, Model, load, streams, train_language, evaluate
from research import persist_model, write_json
from dynamath.v002.__main__ import block, generate
from dynamath.korean_data import question_key


def balanced(rows, tok):
    rng = random.Random(43)
    chosen = []
    for label, size in zip(("0", "1", "2"), (171, 171, 170), strict=True):
        group = sorted((r for r in rows if r["label"] == label),
                       key=lambda r: (len(tok.encode(r["Q"])) + len(tok.encode(r["A"])), r["id"]))
        for bucket in range(5):
            bucket_rows = group[bucket * len(group)//5:(bucket+1)*len(group)//5]
            chosen.extend(rng.sample(bucket_rows, size//5 + (bucket < size%5)))
    return sorted(chosen, key=lambda r: r["id"])


def question_pairs(rows, tok):
    groups = defaultdict(list)
    for row in rows:
        groups[row["label"], len(tok.encode(row["Q"]))].append(row)
    rng = random.Random(2718)
    result = []
    for label in ("0", "1", "2"):
        pairs = []
        for (group_label, _), group in groups.items():
            if group_label != label:
                continue
            remaining = group[:]
            rng.shuffle(remaining)
            while len(remaining) > 1:
                a = remaining.pop()
                idx = next((i for i, b in enumerate(remaining)
                            if question_key(a["Q"]) != question_key(b["Q"])
                            and question_key(a["A"]) != question_key(b["A"])), None)
                if idx is not None:
                    pairs.append((a, remaining.pop(idx)))
        result.extend(rng.sample(pairs, 16))
    return result


@torch.no_grad()
def response_logp(model, tok, questions, answer):
    encoded = [tok.encode(q) for q in questions]
    assert len(encoded[0]) == len(encoded[1])
    reply = tok.encode(answer)
    assert reply
    inp = torch.tensor([[0, *q, 1, *reply[:-1]] for q in encoded]).T
    s, m = model.zero(2)
    score = torch.zeros(2)
    for i, token in enumerate(inp):
        s, m, out, _ = block(model, s, m, i*3, token)
        reply_index = i - len(encoded[0]) - 1
        if reply_index >= 0:
            score += out[0].log_softmax(dim=1)[:, reply[reply_index]]
    return (score / len(reply)).tolist()


def paired_probe(model, tok, pairs):
    raw = []
    for a, b in pairs:
        ab = response_logp(model, tok, [a["Q"], b["Q"]], a["A"])
        ba = response_logp(model, tok, [b["Q"], a["Q"]], b["A"])
        out = [generate(model, r["Q"], 3*(len(tok.encode(r["Q"]))+98)) for r in (a,b)]
        raw.append(dict(ids=[a["id"], b["id"]], label=a["label"],
                        margins=[ab[0]-ab[1],ba[0]-ba[1]],
                        responses=[r["text"] for r in out], eos=[r["eos"] for r in out]))
    values = [statistics.mean(r["margins"]) for r in raw]
    rng = random.Random(2709)
    boot = sorted(statistics.mean(rng.choices(values, k=len(values))) for _ in range(2000))
    return {
        "pairs": len(raw),
        "mean_correct_question_logp_gain": statistics.mean(values),
        "paired_bootstrap_95": [boot[50],boot[1949]],
        "both_answers_prefer_correct_question": sum(min(r["margins"])>0 for r in raw),
        "identical_generated_text_pairs": sum(r["responses"][0]==r["responses"][1] for r in raw),
        "eos": sum(sum(r["eos"]) for r in raw),
        "raw": raw,
    }


def main():
    cfg = json.loads((ROOT/"configs/dynamath/experiment-003a.json").read_text())
    torch.set_num_threads(cfg["threads"])
    splits,tok = load(ROOT/"data/dynamath/001a")
    origin_path = ROOT/"models/dynamath/002a/model1-step18000.pt"
    candidate_path = HERE.parent/"F1-19/step-03000.pt"
    fixed_path = HERE.parents[1]/"003aa/research/early-control/control-step-003000.pt"
    train = balanced(splits["train"],tok)
    pairs = question_pairs(splits["validation"],tok)
    assert len({r["id"] for r in train}) == 512
    assert len({r["id"] for pair in pairs for r in pair}) == 96
    design = dict(steps=3000, training_ids=[r["id"] for r in train],
                  paired_validation_ids=[[r["id"] for r in pair] for pair in pairs],
                  original_labels=dict(Counter(r["label"] for r in splits["train"][:512])),
                  balanced_labels=dict(Counter(r["label"] for r in train)))
    protocol = HERE/"protocol.json"
    if protocol.exists() and json.loads(protocol.read_text()) != design:
        raise ValueError("Protocol mismatch")
    write_json(protocol, design)
    original = {"original-fixed":fixed_path, "original-F1-19":candidate_path}
    for name,path in original.items():
        model,payload = Model.load(path)
        assert payload["restart"]["completed_steps"] == 3000
        assess(name,model,splits,tok,pairs)

    origin = Model.from_002(origin_path)
    edited,_ = Model.load(candidate_path)
    x,y = streams(train,tok,cfg["batch"])
    for name,ast in (("balanced-fixed",origin.asts[0]),("balanced-F1-19",edited.asts[0])):
        latest = HERE/f"{name}.pt"
        if latest.exists():
            model,payload = Model.load(latest)
            assert model.asts[0] == ast
            restart = payload["restart"]
        else:
            model = deepcopy(origin)
            model.asts[0] = deepcopy(ast)
            torch.manual_seed(cfg["seed"])
            random.seed(cfg["seed"])
            restart = None
        step = restart["completed_steps"] if restart else 0
        while step<3000:
            stat,restart = train_language(model,x,y,dict(cfg,steps=min(step+500,3000)),restart)
            assert stat["steps"]>step
            step = stat["steps"]
            persist_model(model,latest,restart=restart)
            print(name,step,flush=True)
        assess(name,model,splits,tok,pairs)
    write_json(HERE/"complete.json", dict(arms=[*original,"balanced-fixed","balanced-F1-19"]))
    print("All four arms complete",flush=True)


def assess(name,model,splits,tok,pairs):
    path = HERE/f"{name}.json"
    if path.exists():
        return
    model.eval()
    validation=evaluate(model,splits["validation"],tok)
    labels={label:evaluate(model,[r for r in splits["validation"] if r["label"]==label],tok)["response_CE"]
            for label in ("0","1","2")}
    probe=paired_probe(model,tok,pairs)
    write_json(path,dict(validation=validation,label_CE=labels,question_swap=probe))
    print(name,round(validation["response_CE"],5),labels,
          round(probe["mean_correct_question_logp_gain"],5),probe["paired_bootstrap_95"],
          probe["identical_generated_text_pairs"],flush=True)


if __name__=="__main__":
    main()


