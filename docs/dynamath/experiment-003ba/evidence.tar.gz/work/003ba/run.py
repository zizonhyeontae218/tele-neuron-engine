"""Train the 50 fixed 003ba candidates sequentially on the local CPU."""
import argparse
import copy
import hashlib
import json
import msvcrt
from pathlib import Path
import random
import sys
import time

HERE = Path(__file__).resolve().parent
AA = HERE.parent / "003aa"
sys.path.insert(0, str(AA))
sys.path.insert(0, str(HERE.parents[1] / "src"))

import torch
from dynamath.v003a.ast import validate
from research import measure, persist_model, write_json
from train_control import ROOT, Model, load, streams, train_language

STEPS = 10_000
MILESTONES = (3_000, STEPS)
SAVE_EVERY = 250


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    origin_path = ROOT / "models/dynamath/002a/model1-step18000.pt"
    shortlist_path = AA / "formula-shortlist.json"
    shortlist = read(shortlist_path)["candidates"]
    cfg = read(ROOT / "configs/dynamath/experiment-003a.json")
    csv = ROOT / "data/dynamath/001a/ChatbotData.csv"
    splits, tokenizer = load(csv.parent)
    train = splits["train"][:512]
    validation = splits["validation"]
    validation_by_id = {row["id"]: row for row in validation}
    prompts = [validation_by_id[i] for i in read(AA / "research/protocol.json")["validation_prompt_ids"]]
    x, y = streams(train, tokenizer, cfg["batch"])
    assert len(shortlist) == len({item["candidate"] for item in shortlist}) == 50
    assert all(item["law"] == 1 and validate(item["ast"]) for item in shortlist)
    protocol = {
        "initial_model": str(origin_path.relative_to(ROOT)),
        "initial_sha256": digest(origin_path),
        "shortlist_sha256": digest(shortlist_path),
        "dataset_sha256": digest(csv),
        "train_ids": [row["id"] for row in train],
        "validation_ids": [row["id"] for row in validation],
        "validation_fifo_ids": [row["id"] for row in prompts],
        "candidate_order": [row["candidate"] for row in shortlist],
        "steps_per_formula": STEPS,
        "total_candidate_updates": len(shortlist) * STEPS,
        "milestones": list(MILESTONES),
        "checkpoint_interval": SAVE_EVERY,
        "torch": str(torch.__version__),
        "training": {key: cfg[key] for key in ("seed", "threads", "batch", "tbptt_slots", "lr")},
        "ranking": "End-point validation response CE, then FIFO EOS failure, then candidate ID.",
        "control": "Existing 003aa fixed-formula validation records at the same update counts.",
    }
    protocol_path = HERE / "protocol.json"
    if protocol_path.exists() and read(protocol_path) != protocol:
        raise RuntimeError("Existing experiment protocol differs from the current configuration")
    write_json(protocol_path, protocol)
    controls = {}
    with (AA / "progress.jsonl").open(encoding="utf-8") as source:
        for line in source:
            item = json.loads(line)
            if item["event"] == "validation" and item["step"] in MILESTONES:
                controls[str(item["step"])] = item
    assert set(controls) == {str(step) for step in MILESTONES}
    write_json(HERE / "control-validation.json", controls)

    torch.set_num_threads(cfg["threads"])
    origin = Model.from_002(origin_path)
    completed = []
    for index, candidate in enumerate(shortlist, start=1):
        name = candidate["candidate"]
        folder = HERE / name
        folder.mkdir(exist_ok=True)
        path = folder / "latest.pt"
        if path.exists():
            model, payload = Model.load(path)
            if model.asts[0] != candidate["ast"] or payload["candidate"] != name:
                raise RuntimeError(f"Checkpoint identity mismatch for {name}")
            restart = payload["restart"]
        else:
            model = copy.deepcopy(origin)
            model.asts[0] = copy.deepcopy(candidate["ast"])
            torch.manual_seed(cfg["seed"])
            random.seed(cfg["seed"])
            restart = None

        step = restart["completed_steps"] if restart else 0
        if not 0 <= step <= STEPS:
            raise RuntimeError(f"Checkpoint out of budget for {name}")
        for milestone in MILESTONES:
            measurement = folder / f"validation-{milestone:05}.json"
            if step > milestone and not measurement.exists():
                raise RuntimeError(f"{name} is missing its {milestone}-step validation")
            while step < milestone:
                target = min(step + SAVE_EVERY, milestone)
                stats, restart = train_language(model, x, y,
                    dict(cfg, steps=target, seconds_cap_per_run=300), restart)
                if stats["steps"] <= step:
                    raise RuntimeError(f"Training made no progress for {name}")
                step = stats["steps"]
                persist_model(model, path, candidate=name, restart=restart, training=stats)
                progress = ((index - 1) * STEPS) + step
                status = dict(candidate=name, index=index, candidate_step=step,
                              completed_formulas=len(completed), total_steps=progress)
                write_json(HERE / "status.json", status)
                print(f"{index:02}/50 {name} {step:05}/{STEPS} updates ({progress}/500000 total)", flush=True)
            if not measurement.exists():
                score = measure(model, validation, prompts, tokenizer)
                if milestone < STEPS:
                    persist_model(model, folder / f"step-{milestone:05}.pt",
                                  candidate=name, restart=restart)
                write_json(measurement, dict(candidate=candidate, updates=milestone, **score))
            if milestone == STEPS:
                metrics = read(measurement)["metrics"]

        completed.append(dict(candidate=name, expression=candidate["expression"], **metrics))
        write_json(HERE / "results.json", dict(
            completed=len(completed), total_formulas=len(shortlist),
            completed_candidate_updates=len(completed) * STEPS,
            ranking=sorted(completed, key=lambda row: (
                row["response_CE"], row["fifo_eos_failure"], row["candidate"])),
        ))
        write_json(HERE / "status.json", dict(candidate=name, index=index,
                  candidate_step=STEPS, completed_formulas=len(completed),
                  total_steps=index * STEPS, complete=len(completed) == len(shortlist)))


def acquire(lock, wait):
    while True:
        lock.seek(0)
        try:
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
            return
        except OSError as error:
            if not wait or error.errno not in (13, 36):
                raise
            time.sleep(10)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--after-current-training", action="store_true")
    args = parser.parse_args()
    with (HERE / "run.lock").open("a+b") as lock:
        if args.after_current_training:
            print("Waiting for the active 003ba trainer to release its lock.", flush=True)
        acquire(lock, wait=args.after_current_training)
        if not args.after_current_training:
            main()
        from postprocess import run
        run(HERE)
