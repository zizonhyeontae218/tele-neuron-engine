"""Run the local 003aa research from a frozen 500,000-update control."""
import copy
import hashlib
import json
import os
from pathlib import Path
import random
import time

import torch

from train_control import ROOT, evaluate, load, Model, streams, train_language
from dynamath.v002 import Session
from dynamath.v002.__main__ import generate
from dynamath.v003a.ast import BASE, expression, interpret, validate

STAGES = ((64, 16), (400, 4), (2000, 1))
NAMES = ("민수", "지수", "영희", "철수", "수진", "민지", "유진", "지민")
RANK_FIELDS = ("response_CE", "response_omission_rate", "fifo_omission",
               "fifo_eos_failure", "fifo_repeat_4gram", "nodes")


def write_json(path, payload):
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, indent=2, ensure_ascii=False, allow_nan=False) + "\n",
                   encoding="utf-8")
    os.replace(tmp, path)


def persist_model(model, path, **details):
    tmp = path.with_suffix(".tmp")
    model.save(tmp, **details)
    os.replace(tmp, path)


def measure(model, rows, prompts, tok):
    start = time.monotonic()
    metrics = evaluate(model, rows, tok)
    metrics["teacher_forced_seconds"] = time.monotonic() - start
    start = time.monotonic()
    samples = [dict(row_id=r["id"], reference=r["A"],
                    **generate(model, r["Q"], 3 * (len(tok.encode(r["Q"])) + 2 + 96)))
               for r in prompts]
    metrics["fifo_seconds"] = time.monotonic() - start
    metrics["fifo_omission"] = sum(r["response_omission"] for r in samples) / len(samples)
    metrics["fifo_eos_failure"] = sum(not r["eos"] for r in samples) / len(samples)
    metrics["fifo_question_emissions"] = sum(bool(r["question_events"]) for r in samples)
    metrics["fifo_uncomposed_jamo"] = sum(r["uncomposed_jamo"] for r in samples)
    metrics["fifo_mean_final_queue"] = sum(r["final_queue"] for r in samples) / len(samples)
    repeated, total = 0, 0
    for row in samples:
        tokens = [i for i in row["token_ids"] if i >= 5]
        grams = list(zip(tokens, tokens[1:], tokens[2:], tokens[3:]))
        total += len(grams)
        repeated += len(grams) - len(set(grams))
    metrics["fifo_repeat_4gram"] = repeated / max(total, 1)
    metrics["nodes"] = validate(model.asts[0])
    return dict(metrics=metrics, samples=samples)


def memory_probes(model, tok):
    def turn(session, question, budget):
        session.enqueue([0, *tok.encode(question), 1])
        responding = False
        tokens = []
        for _ in range(3 * (len(session.queue) + budget)):
            token = session.tick()
            responding |= session.log[-1]["admitted"] == (1, "external")
            if responding and token is not None:
                tokens.append(token)
                if token == 2:
                    break
        return {"text": tok.decode(tokens), "tokens": tokens, "eos": 2 in tokens,
                "bot_admitted": responding, "final_queue": len(session.queue)}

    rows = []
    for name in NAMES:
        original = Session(model)
        first = turn(original, f"내 이름은 {name}이야.", 48)
        snapshot = original.snapshot()
        for clear_queue in (False, True):
            for reset in ("none", "S_only", "m_only", "both"):
                session = Session(model)
                session.restore(snapshot)
                zero_s, zero_m = model.zero()
                if reset in ("S_only", "both"):
                    session.s = zero_s
                if reset in ("m_only", "both"):
                    session.m = zero_m
                if clear_queue:
                    pending = [(token, source) for token, source in session.queue if source != "feedback"]
                    session.queue.clear()
                    session.queue.extend(pending)
                second = turn(session, "내 이름이 뭐야?", 96)
                rows.append(dict(name=name, reset=reset, clear_pending_feedback=clear_queue,
                                 first=first, second=second, hit=name in second["text"]))
    return rows


def synthetic(asts):
    """Fit each AST's scalar on one planted recurrence and score disjoint inputs."""
    x = torch.linspace(-1, 1, 101)
    train_x, test_x = x[::2], x[1::2]

    def truth(x):
        return (x.tanh() + 0.3 * x.tanh().sin()).clamp(-1, 1)

    planted = {"op": "residual", "left": BASE, "right": {"op": "sin", "arg": {"op": "S"}}}
    results = {}
    for name, ast in {**asts, "planted_positive_control": planted}.items():
        alpha = torch.nn.Parameter(torch.tensor(0.))
        optimizer = torch.optim.Adam([alpha], lr=.05)

        def predict(z):
            return interpret(ast, z, z, torch.zeros_like(z), alpha)

        for _ in range(100):
            optimizer.zero_grad()
            loss = (predict(train_x) - truth(train_x)).square().mean() + alpha * 0
            loss.backward()
            optimizer.step()
        with torch.no_grad():
            state = expected = torch.linspace(-.9, .9, 19)
            for _ in range(9):
                state, expected = predict(state), truth(expected)
            results[name] = dict(alpha=float(alpha),
                                 one_step_mse=float((predict(test_x)-truth(test_x)).square().mean()),
                                 nine_step_mse=float((state-expected).square().mean()))
    return dict(target="clip(tanh(x)+0.3*sin(tanh(x)))", updates_per_ast=100,
                observations=results)


def run_research(frozen, stop, report, *, target=500000, stages=STAGES, prompt_count=24,
                 train_limit=512, validation_limit=None, test_limit=None, shortlist_limit=50):
    directory = frozen.parent / "research"
    directory.mkdir(exist_ok=True)
    origin, payload = Model.load(frozen)
    if payload["restart"]["completed_steps"] != target:
        raise ValueError(f"Research needs a frozen checkpoint at {target} additional steps")
    cfg = json.loads((ROOT / "configs/dynamath/experiment-003a.json").read_text())
    splits, tok = load(ROOT / "data/dynamath/001a")
    shortlist = json.loads((frozen.parent / "formula-shortlist.json").read_text(encoding="utf-8"))
    asts = {"control": BASE, **{r["candidate"]: r["ast"] for r in shortlist["candidates"][:shortlist_limit]}}
    if len(asts) != shortlist_limit + 1 or any(keep > shortlist_limit for _, keep in stages):
        raise ValueError("Invalid shortlist or stage size")
    train = splits["train"][:train_limit]
    validation = splits["validation"][:validation_limit]
    test = splits["test"][:test_limit]
    val_prompts = random.Random(43).sample(validation, prompt_count)
    test_prompts = random.Random(44).sample(test, prompt_count)
    x, y = streams(train, tok, cfg["batch"])
    protocol = dict(frozen_sha256=hashlib.sha256(frozen.read_bytes()).hexdigest(), target=target,
                    shortlist_sha256=hashlib.sha256((frozen.parent / "formula-shortlist.json").read_bytes()).hexdigest(),
                    stages=[list(s) for s in stages], train_ids=[r["id"] for r in train],
                    validation_ids=[r["id"] for r in validation], test_ids=[r["id"] for r in test],
                    validation_prompt_ids=[r["id"] for r in val_prompts], test_prompt_ids=[r["id"] for r in test_prompts],
                    rank_fields=list(RANK_FIELDS), law_index=1, optimizer="new Adam per arm",
                    research_initialization="same frozen weights; fresh recurrent state and stream position")
    protocol_path = directory / "protocol.json"
    if protocol_path.exists() and json.loads(protocol_path.read_text(encoding="utf-8")) != protocol:
        raise ValueError("Research protocol differs from the saved run")
    write_json(protocol_path, protocol)
    candidates = list(asts)[1:]
    for budget, keep in stages:
        by_name = {}
        for name in ["control", *candidates]:
            if stop.is_set():
                return False
            result = directory / f"{name}-{budget:04d}.json"
            if result.exists():
                by_name[name] = json.loads(result.read_text(encoding="utf-8"))
                continue
            path = directory / f"{name}.pt"
            if path.exists():
                model, saved = Model.load(path)
                restart = saved["restart"]
            else:
                model = copy.deepcopy(origin)
                model.asts[0] = asts[name]
                torch.manual_seed(cfg["seed"])
                random.seed(cfg["seed"])
                restart = None
            step = restart["completed_steps"] if restart else 0
            while step < budget and not stop.is_set():
                report(f"003aa 공식 비교 · {name} · {step:,} / {budget:,}")
                stats, restart = train_language(model, x, y,
                                                dict(cfg, steps=min(step+50, budget), seconds_cap_per_run=300),
                                                restart)
                step = stats["steps"]
                persist_model(model, path, restart=restart)
            if stop.is_set():
                return False
            score = measure(model, validation, val_prompts, tok)
            score.update(name=name, budget=budget, expression=expression(asts[name]), ast=asts[name])
            write_json(result, score)
            by_name[name] = score
        metrics = {name: row["metrics"] for name, row in by_name.items()}
        # Sum per-metric ranks; ties in individual metrics share the same rank.
        ranks = {name: sum(sum(other[key] < m[key] for other in metrics.values()) for key in RANK_FIELDS)
                 for name, m in metrics.items()}
        candidates = sorted(candidates, key=lambda name: (ranks[name], metrics[name]["response_CE"], name))[:keep]
        write_json(directory / f"stage-{budget:04d}.json",
                   dict(advance=candidates, ranks=ranks, validation=metrics))
    selected = candidates[0]
    write_json(directory / "selection.json", dict(selected=selected, comparator="control", stages=protocol["stages"]))
    chosen, _ = Model.load(directory / f"{selected}.pt")
    for name, model in (("frozen", origin), ("control", Model.load(directory / "control.pt")[0]), (selected, chosen)):
        if stop.is_set():
            return False
        result = directory / f"test-{name}.json"
        if not result.exists():
            report(f"003aa 최종 테스트 · {name}")
            score = measure(model, test, test_prompts, tok)
            score["multi_turn_memory"] = memory_probes(model, tok)
            write_json(result, score)
    if stop.is_set():
        return False
    restored = copy.deepcopy(chosen)
    restored.asts[0] = BASE
    write_json(directory / "ablations.json",
               dict(selected=selected, selected_alpha=float(chosen.alpha[0].detach()),
                    restored_ast=measure(restored, validation, val_prompts, tok),
                    synthetic=synthetic(asts)))
    write_json(directory / "complete.json", dict(completed=True, selected=selected, frozen=protocol["frozen_sha256"]))
    return True

