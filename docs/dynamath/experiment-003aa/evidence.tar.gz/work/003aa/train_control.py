"""Keep training the 003a Korean control until the desktop stop button is clicked."""
import argparse
import json
import shutil
import os
from pathlib import Path
import random
import sys
from threading import Event, Thread
import traceback
import types
import tkinter as tk
from tkinter import ttk

# The legacy 002 CLI imports Unix resource for its report only. The reused
# training and evaluation functions do not use it.
if sys.platform == "win32":
    with_resource = types.ModuleType("resource")
    sys.modules["resource"] = with_resource
try:
    from dynamath.v002.__main__ import evaluate, streams, train_language
finally:
    if sys.platform == "win32":
        del sys.modules["resource"]
import torch
from dynamath.korean_data import fetch, load
from dynamath.v003a import Model

ROOT = Path(__file__).resolve().parents[2]
RUN = Path(__file__).resolve().parent
CHUNK = 50
VALIDATE_EVERY = 5000


def worker(stop, report, run_dir=RUN, chunk=CHUNK, validate_every=VALIDATE_EVERY, target=None, research=False):
    checkpoint = run_dir / "control-latest.pt"
    log = run_dir / "progress.jsonl"
    def record(**data):
        with log.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(data, allow_nan=False) + "\n")

    try:
        report("한국어 데이터와 모델을 불러오는 중…")
        cfg = json.loads((ROOT / "configs/dynamath/experiment-003a.json").read_text())
        torch.set_num_threads(cfg["threads"])
        torch.manual_seed(cfg["seed"])
        random.seed(cfg["seed"])
        csv = ROOT / "data/dynamath/001a/ChatbotData.csv"
        if not csv.exists():
            csv.write_bytes(fetch(csv.name))
        splits, tokenizer = load(csv.parent)
        train_rows = splits["train"][:512]
        validation_rows = splits["validation"]
        x, y = streams(train_rows, tokenizer, cfg["batch"])
        if checkpoint.is_file():
            model, payload = Model.load(checkpoint)
            restart = payload["restart"]
            metric = payload["validation"]
            step = restart["completed_steps"]
            if target is not None and step > target:
                raise ValueError("Saved checkpoint already exceeds the requested target")
            record(event="resume", step=step, target=target, validation_every=validate_every)
        else:
            model = Model.from_002(ROOT / "models/dynamath/002a/model1-step18000.pt")
            restart = None
            metric = None
            step = 0
            record(event="start", step=step, origin_updates=18000, train_rows=len(train_rows),
                   validation_rows=len(validation_rows), validation_every=validate_every, chunk=chunk)

        def save():
            temporary = checkpoint.with_suffix(".tmp")
            model.save(temporary, restart=restart, validation=metric, config_run=cfg,
                       origin="002a/model1-step18000.pt")
            os.replace(temporary, checkpoint)

        while not stop.is_set():
            details = f"마지막 검증 {metric['step']:,}스텝 · CE {metric['response_CE']:.5f}" if metric else ""
            if (step % validate_every == 0 or step == target) and (not metric or metric["step"] != step):
                report(f"{step:,}스텝 · 한국어 검증 중…")
                metric = dict(step=step, **evaluate(model, validation_rows, tokenizer))
                record(event="validation", **metric)
                if restart is not None:
                    save()
            if restart is not None and ((step > 0 and step % 50000 == 0) or step == target):
                archive = run_dir / f"control-step-{step:06}.pt"
                if not archive.exists():
                    temporary = archive.with_suffix(".tmp")
                    shutil.copyfile(checkpoint, temporary)
                    os.replace(temporary, archive)
            if step == target:
                archive = run_dir / f"control-step-{step:06}.pt"
                record(event="target_complete", step=step, checkpoint=archive.name)
                if research and not stop.is_set():
                    from research import run_research
                    finished = run_research(archive, stop, report)
                    report("003aa 후속 실험 완료" if finished else "후속 실험 중지 · 완료한 결과 저장됨", done=True)
                else:
                    report(f"추가 {step:,}스텝 완료 · 체크포인트 저장됨", done=True)
                return
            if stop.is_set():
                break
            goal = f" / {target:,}" if target is not None else ""
            report(f"학습 중 · 추가 {step:,}{goal}스텝\n{details}")
            next_step = min(step + chunk, target) if target is not None else step + chunk
            cfg.update(steps=next_step, seconds_cap_per_run=300)
            stats, restart = train_language(model, x, y, cfg, restart)
            step = stats["steps"]
            save()
            record(event="checkpoint", step=step, seconds=stats["seconds"], history=stats["history"])
        record(event="stop", step=step, saved=checkpoint.is_file())
        suffix = "체크포인트 저장 완료" if checkpoint.is_file() else "학습 시작 전에 정지"
        report(f"학습 정지 · 추가 {step:,}스텝\n{suffix}", done=True)
    except Exception:
        (run_dir / "error.log").write_text(traceback.format_exc(), encoding="utf-8")
        report("학습 중 오류가 발생했습니다.\nerror.log를 확인하세요.", done=True)
        raise


def main():
    from queue import Empty, Queue
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", type=int)
    parser.add_argument("--research", action="store_true")
    args = parser.parse_args()
    if args.target is not None and args.target < 1:
        parser.error("--target must be positive")
    messages = Queue()
    stop = Event()
    root = tk.Tk()
    root.title("DynaMath 003aa · 003a 한국어 학습")
    width, height = 480, 260
    x = (root.winfo_screenwidth() - width) // 2
    y = (root.winfo_screenheight() - height) // 2
    root.geometry(f"{width}x{height}+{x}+{y}")
    root.resizable(False, False)
    root.attributes("-topmost", True)
    root.after(1200, lambda: root.attributes("-topmost", False))
    status = tk.StringVar(value="학습을 준비하는 중…")
    ttk.Label(root, textvariable=status, justify="center", anchor="center").place(
        relx=0.5, rely=0.23, anchor="center"
    )

    def request_stop():
        stop.set()
        status.set("중지 요청 접수 · 현재 학습 묶음 정리 중…")
        button.configure(state="disabled")

    button = ttk.Button(root, text="학습 중지", command=request_stop, width=22)
    button.place(relx=0.5, rely=0.5, anchor="center", height=48)
    ttk.Label(root, text="중지해도 마지막 체크포인트에서 다시 시작할 수 있습니다.").place(
        relx=0.5, rely=0.77, anchor="center"
    )
    root.protocol("WM_DELETE_WINDOW", request_stop)

    def poll():
        try:
            while True:
                message, done = messages.get_nowait()
                if done:
                    status.set(message)
                    button.configure(text="닫기", state="normal", command=root.destroy)
                    root.protocol("WM_DELETE_WINDOW", root.destroy)
                elif not stop.is_set():
                    status.set(message)
        except Empty:
            pass
        root.after(200, poll)

    def report(message, done=False):
        messages.put((message, done))

    Thread(target=worker, args=(stop, report), kwargs={"target": args.target, "research": args.research}).start()
    poll()
    root.mainloop()


if __name__ == "__main__":
    main()

