"""Validation-only check of the best early control and the FIFO feedback path."""
import copy
import json
from pathlib import Path
import random
import sys

import torch

from train_control import ROOT, Model, evaluate, load, streams, train_language
from research import measure, persist_model, write_json
from dynamath.v002 import Session

RUN = Path(__file__).resolve().parent
OUT = RUN / "research" / "early-control"


def feedback_probe(model, prompts, tokenizer, feedback):
    rows = []
    for row in prompts:
        session = Session(model)
        question = [0, *tokenizer.encode(row["Q"]), 1]
        session.enqueue(question)
        tokens = []
        question_emissions = 0
        admitted = False
        for _ in range(3 * (len(question) + 96)):
            token = session.tick()
            admitted |= session.log[-1]["admitted"] == (1, "external")
            if token is None:
                continue
            if not feedback:
                assert session.queue.pop() == (token, "feedback")
            if admitted:
                tokens.append(token)
                if token == 2:
                    break
            else:
                question_emissions += 1
        rows.append(dict(row_id=row["id"], tokens=tokens, text=tokenizer.decode(tokens),
                         eos=2 in tokens, bot_admitted=admitted, question_emissions=question_emissions,
                         final_queue=len(session.queue)))
    return rows


def main():
    OUT.mkdir(exist_ok=True)
    cfg = json.loads((ROOT / "configs/dynamath/experiment-003a.json").read_text())
    torch.set_num_threads(cfg["threads"])
    torch.manual_seed(cfg["seed"])
    random.seed(cfg["seed"])
    splits, tokenizer = load(ROOT / "data/dynamath/001a")
    train = splits["train"][:512]
    validate = splits["validation"]
    plan = json.loads((RUN / "research/protocol.json").read_text(encoding="utf-8"))
    lookup = {r["id"]: r for r in validate}
    prompts = [lookup[i] for i in plan["validation_prompt_ids"]]
    x, y = streams(train, tokenizer, cfg["batch"])
    stage = json.loads((RUN / "research/selection.json").read_text())["selected"]
    candidate, _ = Model.load(RUN / f"research/{stage}.pt")
    early_path = OUT / "control-step-003000.pt"
    if early_path.exists():
        early, _ = Model.load(early_path)
    else:
        early = Model.from_002(ROOT / "models/dynamath/002a/model1-step18000.pt")
        stats, restart = train_language(early, x, y, dict(cfg, steps=3000, seconds_cap_per_run=1200))
        assert stats["steps"] == 3000
        persist_model(early, early_path, restart=restart, training=stats)
    early_metrics = evaluate(early, validate, tokenizer)
    progress = [json.loads(line) for line in (RUN / "progress.jsonl").read_text().splitlines()]
    original = next(v for v in progress if v["event"] == "validation" and v["step"] == 3000)
    for key, value in early_metrics.items():
        assert value == original[key], (key, value, original[key])
    print("3,000-step checkpoint reproduced exactly on validation", flush=True)

    fixed, edited = copy.deepcopy(early), copy.deepcopy(early)
    edited.asts[0] = copy.deepcopy(candidate.asts[0])
    for name, model in (("control", fixed), (stage, edited)):
        path = OUT / f"{name}-from-3000-plus-2000.pt"
        if path.exists():
            restored, payload = Model.load(path)
            model.load_state_dict(restored.state_dict())
            assert payload["restart"]["completed_steps"] == 2000
        else:
            torch.manual_seed(cfg["seed"])
            random.seed(cfg["seed"])
            stats, restart = train_language(model, x, y, dict(cfg, steps=2000, seconds_cap_per_run=1200))
            assert stats["steps"] == 2000
            persist_model(model, path, restart=restart, training=stats)
        print(f"{name}: 2,000 matched updates complete", flush=True)

    result = {}
    for name, model in (
        ("control-3000", early),
        ("control-50000", Model.load(RUN / "control-step-050000.pt")[0]),
        ("control-500000", Model.load(RUN / "control-step-500000.pt")[0]),
        ("matched-control-from-3000", fixed),
        ("matched-edit-from-3000", edited),
        ("selected-edit-from-500000", candidate),
    ):
        model.eval()
        normal = measure(model, validate, prompts, tokenizer)
        enabled = feedback_probe(model, prompts, tokenizer, feedback=True)
        assert all(a["token_ids"] == b["tokens"] for a, b in zip(normal["samples"], enabled, strict=True))
        disabled = feedback_probe(model, prompts, tokenizer, feedback=False)
        result[name] = dict(training=evaluate(model, train, tokenizer),
                            validation=normal["metrics"], feedback_enabled=enabled,
                            feedback_disabled=disabled)
        print(name, "train/val CE",
              round(result[name]["training"]["response_CE"], 5),
              round(result[name]["validation"]["response_CE"], 5), flush=True)

    write_json(OUT / "diagnostics.json", dict(replayed_step=3000, matched_updates=2000,
               selected=stage, validation_prompt_ids=plan["validation_prompt_ids"], results=result))
    print("PASS: replay, matched validation, and FIFO counterfactual complete", flush=True)


if __name__ == "__main__":
    main()

